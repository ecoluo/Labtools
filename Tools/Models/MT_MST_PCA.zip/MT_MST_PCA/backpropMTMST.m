% function backpropMTMST
% Backpropagation algorithm in classifying handwriting digits.
% Implemented by a feedfoward multilayer perceptron.
% HH 2013.11.25

clear;
% load HeadingResponse_-30_1_-1
load HeadingResponse_-8

headings =   -8 * 0.5.^(0:5) ; %-30:1:-1;
headings = [headings 0 -headings(end:-1:1)];

% normalized to 0:255 (matching the amp of "digits" sets)
%response = (response - min(response(:)))*255/range(response(:));

%% Parameters
close all;

NHIND=[30];   % # of neurons in the hidden layer(s)
INIT=0.07; % scale of initial values
ETA=.3;   % learning rate
f=inline('1./(1+exp(-x))');  % activation curve
phy=inline('y.*(1-y)');   %  phy(x)=f'(f^-1(x)); the slope
plotInterval = 300;

%protocol = 'HD';
protocol = 'EST';

%% Initialization

resolutionX = fix(sqrt(size(response,1)));
resolutionY = fix(size(response,1)/resolutionX);

if strcmp(protocol,'EST')
    numHeadings = size(response,2);
elseif strcmp(protocol,'HD')
    numHeadings = 2;    
end

% Data sets
maxEpoch=200;     % Train session
bootStrapNum = 10;   % Repetition per epoch (test cycle)
train = repmat(response,1,bootStrapNum);

if strcmp(protocol,'EST')
    % Peak desired function
    sigma = 1/(numHeadings/3/20) ;
    spread = exp(-(sigma:sigma:sigma*numHeadings/3));
    trainDesire = eye(numHeadings);
    for i = 1:length(spread)
        trainDesire =  trainDesire + circshift(eye(numHeadings),i)*spread(i) + circshift(eye(numHeadings),-i)*spread(i);
    end
elseif strcmp(protocol,'HD')
    trainDesire = [repmat([1 0]',1,(size(response,2)-1)/2) [0.5 0.5]' repmat([0 1]',1,(size(response,2)-1)/2)];
end

trainDesire = repmat(trainDesire,1,bootStrapNum);
trainResult=zeros(numHeadings,size(trainDesire,2));

if strcmp(protocol,'EST')
    test = train(:,1:numHeadings);
    testDesire = trainDesire(:,1:numHeadings);
    testResult=zeros(numHeadings,size(testDesire,2));
elseif strcmp(protocol,'HD')
    test = train(:,1:end/10);
    testDesire = trainDesire(:,1:end/10);
    testResult = zeros(numHeadings,size(testDesire,2));
    
end

% Add some noise... 
train = train + randn(size(train))*mean(abs(train(:,1))).*train; % Possion like
test = test + randn(size(test))*mean(abs(test(:,1))).*test;

% Layers setting
N=[size(response,1) NHIND numHeadings]; % N_l
L=length(N)-1;  % # of connection layers 
X={}; W={}; b={}; delta={};   % cell definition

for l=1:L+1     %  for all cell layers
    X=[X,zeros(N(l),1)];    % activity
end

for l=1:L        % for all connection layers           
    W=[W,INIT*rand(N(l+1),N(l))];   % connection weights
    b=[b,INIT*(rand(N(l+1),1)-0.5)];          % bias
    delta=[delta,zeros(N(l+1),1)];
end

step=0;  %  step #. of each epoch

errTrain=zeros(1,maxEpoch);
rightTrain=zeros(1,maxEpoch);
errTest=zeros(1,maxEpoch);
rightTest=zeros(1,maxEpoch);

% figure initialization
scrsz = get(0,'ScreenSize');
f1=figure('OuterPosition',[1 scrsz(4)/3 scrsz(3)/2 scrsz(4)/3*2]);  % the first hidden layer
f2=figure('OuterPosition',[scrsz(3)/2 1 scrsz(3)/2 scrsz(4)]);  % errors

f3=figure('OuterPosition',[scrsz(3)/2 scrsz(4)/2 scrsz(3)/4 scrsz(4)/2]); 
subplot(4,1,1:3); 
% weights of the last layer
weight=line('erase','normal','xdata',[],'ydata',[],'Marker','o','LineStyle','none');   
subplot(4,1,4); fplot(f,[-10 10]);  hold on;   
% dynamic range of the first layer
act=line('erase','normal','xdata',[],'ydata',[],'Marker','o','Color','r','LineStyle','none');

f4=figure('OuterPosition',[1 numHeadings scrsz(3)/2 scrsz(4)/3-10]);
            
            
%%% Training and testing 

for epoch=1:maxEpoch
    
    %  ===== Training ======
    r=rand(1,size(train,2));      % initialize the training sequence randomly for each epoch
    [defalt, trainSeq]=sort(r);
     
    for n=trainSeq
        
        % ===== Forward Pass ====
       %  X{1}=double(train(:,n)/255);    % Input layer
        X{1} = double(train(:,n));
       
        for l=1:L    % for connection layers
            X{l+1}=f(W{l}*X{l}+b{l});     % left multiply of  Wij*Xj1
        end
        trainResult(:,n)=X{L+1};            %  save output
        
        % ===== Error Computation ====
        delta{L}=phy(X{L+1}).*(trainDesire(:,n)-X{L+1});
        
        % ===== Backward Pass =======
        for l=L-1:-1:1
            delta{l}=phy(X{l+1}).*(delta{l+1}'*W{l+1})';  % right multiply of delta(1,i)*W(i,j)
        end
        
        % ===== Learning Updates =======
        for l=1:L   
            W{l}=W{l}+ETA*delta{l}*X{l}';  % delta(i,1)*X(1,j)
            b{l}=b{l}+ETA*delta{l};
        end
               
        % ===== Illustration ======
                
        step=step+1;
        if rem(step,plotInterval)==0
          %  keyboard
            % Connection weights of the last layer
            figure(f3);     
            % set(weight,'xdata',1:numel(W{L}),'ydata',reshape(W{L},1,numel(W{L})));
            subplot(4,1,1:3); 
            [a,sorting] = sort(mean(abs(W{2})),'descend');
            [default,whereMax] = max(W{2}(:,sorting(1:24)));
            [default, sorting2] = sort(whereMax);
            imagesc(W{2}(:,sorting(sorting2))'); axis image

            % dynamic range of the first layer
            set(act,'xdata',W{1}*X{1}+b{1},'ydata',f(W{1}*X{1}+b{1}));                          
            title(['Epoch = ', num2str(epoch) ',  step = ' num2str(rem(step,size(train,2)))]);

            
            % Plot the first hidden layer
            figure(f1); 
            %{
            m=ceil(sqrt(N(2)));
            for nhidden=1:N(2)
                subplot(m,m,nhidden);
                imagesc(reshape(W{1}(nhidden,1:resolutionX*resolutionY),resolutionX,resolutionY));
                colormap hot;
                axis square; axis off;
            end
            %}
            ranges = 1:24;
            preferred = 0:22.5:355; % 0:45:315; % degree
            prefVector = exp(preferred*pi/180*sqrt(-1));
            res = sqrt(size(W{1},2)/length(preferred));
            
            for hiddenNo = 1: length(ranges)
                weightMT = W{1}(sorting(sorting2(hiddenNo)),:);  % Just plot the most important MST
                
                
                % Vector sum to get a preferred optical flow pattern
                hiddenLayer(hiddenNo,:) = prefVector * reshape(weightMT,res*res,length(preferred))';
                subplot_tight(floor(sqrt(length(ranges))),ceil(length(ranges)/floor(sqrt(length(ranges)))),hiddenNo,[0.02 0.02]);
                q=quiver(reshape(real(hiddenLayer(hiddenNo,:)),res,res),reshape(imag(hiddenLayer(hiddenNo,:)),res,res),1.5);
                set(q,'color','b','linewidth',2);
                adjust_quiver_arrowhead_size(q,1.7);
                axis tight image;
            end
            
            % Outputlayer
            outputLayer = W{2}(:,sorting(sorting2(ranges)))*hiddenLayer;
            if strcmp(protocol,'EST')
                plotOutput = 1:11:size(W{2},1);
            elseif strcmp(protocol,'HD')
                plotOutput = 1:2;
            end
                        
            nOutput = 1;
            figure(5);
            for outputNo = plotOutput
                subplot_tight(floor(sqrt(length(plotOutput))),ceil(length(plotOutput)/floor(sqrt(length(plotOutput)))),nOutput,[0.02 0.02]);
                q=quiver(reshape(real(outputLayer(outputNo,:)),res,res),reshape(imag(outputLayer(outputNo,:)),res,res),1.5);
                nOutput = nOutput+1;
                set(q,'color','b','linewidth',2);
                adjust_quiver_arrowhead_size(q,1.7);
                axis tight image;
            end
            
            
            % Compare desired and actual
            figure(f4);
            % Desire outputN
            title(['Epoch = ', num2str(epoch) ',  step = ' num2str(rem(step,size(train,2)))]);
            subplot(2,5,1:3);
            bar(trainDesire(:,n));
            
            % Actual output
            subplot(2,5,6:8);
            bar(trainResult(:,n));
            
            % Real Image
            subplot(2,5,[4 10]);
            imagesc(reshape(train(1:resolutionX*resolutionY,n),resolutionX,resolutionY));
            
        end
        
    end    % Training End
    
    % ====  Error computation ===
    % Training squared error
    errTrain(epoch)=1/2*mean(mean((trainDesire-trainResult).^2));
    % Training class error
    [default,actualClass]=max(trainResult);    % the final classification answer
    [default,desireClass]=max(trainDesire);    % the desired answer (0->10)
    rightTrain(epoch)=sum(actualClass==desireClass)/size(desireClass,2)*100;  % percentage of correct
    
    if strcmp(protocol,'EST')        % Confusion Matrix
        confusionMatTrain=zeros(numHeadings);
        for n=1:size(train,2)
            confusionMatTrain(actualClass(n),desireClass(n))=confusionMatTrain(actualClass(n),desireClass(n))+1;
        end
    elseif strcmp(protocol,'HD')     % Psychometric curve
        rightwardChoiceTrain =  sum(reshape(actualClass,length(headings),[])'-1,1)/ (length(actualClass)/length(headings));
        psychoTrain = FitCumGauss(headings,rightwardChoiceTrain);
     % psychoTrain =cum_gaussfit_max1([headings,rightwardChoiceTrain]);
     
    end
    
    
    % ===== Test =======
    for n=1:size(test,2)
        
        % ===== Forward Pass ====
        X{1}=double(test(:,n));    % Input layer
        for l=1:L    % for connection layers
            X{l+1}=f(W{l}*X{l}+b{l});     % left multiply of  Wij*Xj1
        end
        testResult(:,n)=X{L+1};            %  save output
        
    end  % Test End
    
    % =====  Error computation =====
    % Test squared error
    errTest(epoch)=1/2*mean(mean((testDesire-testResult).^2));
    % Test class error
    [default,actualClass]=max(testResult);    % the final classification answer
    [default,desireClass]=max(testDesire);    % the desired answer (0->10)
    rightTest(epoch)=sum(actualClass==desireClass)/size(desireClass,2)*100;  % percentage of correct
    
    if strcmp(protocol,'EST')
        % Confusion Matrix
        confusionMatTest=zeros(numHeadings);
        for n=1:size(test,2)
            confusionMatTest(actualClass(n),desireClass(n))=confusionMatTest(actualClass(n),desireClass(n))+1;
        end
    elseif strcmp(protocol,'HD')
        rightwardChoiceTest =  sum(reshape(actualClass,length(headings),[])'-1,1)/ (length(actualClass)/length(headings));
%        psychoTest = FitCumGauss (headings,rightwardChoiceTest);
    end
    
    % ===== Plot Errors =======
    figure(f2);
    subplot 321; plot(errTrain(1:epoch),'-o'); title('Training'); xlim([1 maxEpoch]);
    subplot 323; plot(rightTrain(1:epoch),'-o'); xlim([1 maxEpoch]); ylim([0 100]);
    
    subplot 322; plot(errTest(1:epoch),'-o'); title('Test');xlim([1 maxEpoch]);
    subplot 324; plot(rightTest(1:epoch),'-o'); xlim([1 maxEpoch]); ylim([0 100]);
    
    if strcmp(protocol,'EST')
        subplot 325; contour3(confusionMatTrain,30); view (0,90);
        xlabel('Desire'); ylabel('Answer'); set(gca,'xtick',[1:numHeadings],'ytick',[1:numHeadings]);
        subplot 326; contour3(confusionMatTest,30); view (0,90);
        xlabel('Desire'); ylabel('Answer'); set(gca,'xtick',[1:numHeadings],'ytick',[1:numHeadings]);
    elseif strcmp(protocol,'HD')
        subplot 325; 
        plot(headings,rightwardChoiceTrain,'o'); xlim([min(headings) max(headings)]); ylim([-0.05 1.05]);
        subplot 326;
        plot(headings,rightwardChoiceTest,'o'); xlim([min(headings) max(headings)]); ylim([-0.05 1.05]);
    end
    
    %     save result.mat
    
end   % epoch end

save(sprintf('%s_%gx%g_init%g_eta%g.mat',protocol,size(response,1),size(response,2),INIT,ETA),'W','b');



