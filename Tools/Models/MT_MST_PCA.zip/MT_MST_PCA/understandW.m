% Reorganize resulted W to get a better understanding
load ('HD_2704x61_init_eta')

%% Hidden -> Output ("Readout of MST by LIP")
% sort by abs weight
[a,sorting] = sort(mean(abs(W{2})),'descend');
imagesc(W{2}(:,sorting)'); axis image
figure; bar(a);

%% sort by peak
ranges = 1:23;
W2 = W{2}(:,sorting(ranges));
[~,whereMax] = max(W2);
[~, sorting2] = sort(whereMax);
figure; imagesc(W2(:,sorting2)'); axis image


%% Input --> Hidden ("Readout of MT by MST")

preferred = 0:22.5:355; % 0:45:315; % degree
n = sqrt(size(W{1},2)/length(preferred));
if n ~= fix(n) ; disp('Warning: Size error..'); end

% preferred vectors (in complex numbers)
prefVector = exp(preferred*pi/180*sqrt(-1));

for hiddenNo = 1: length(ranges)    
    weightMT = W{1}(sorting(sorting2(hiddenNo)),:);  % Just plot the most important MST
   
    % Plotting different preferred MT cells
    
    %{
    figure;
    temp = reshape(weightMT,n,n,1,length(preferred));
    for i = 1:length(preferred)
        h = subplot_tight(floor(sqrt(length(preferred))),ceil(length(preferred)/floor(sqrt(length(preferred)))),i,[0.02 0.02]);
        imagesc(temp(:,:,1,i));
        
        colormap(jet)
        caxis([min(temp(:)) max(temp(:))]);
        axis(h,'square','off');
        hold on;
        plot([n/2 n/2+n/4*cosd(preferred(i))]+0.5, [n/2 n/2+n/4*sind(preferred(i))]+0.5, 'k-','linewidth',4);
        plot(n/2+n/4*cosd(preferred(i))+0.5, n/2+n/4*sind(preferred(i))+0.5,'ok','markersize',10,'markerfacec','k');
    end
    %}
    
    % Vector sum to get a preferred optical flow pattern
    hiddenLayer(hiddenNo,:) = prefVector * reshape(weightMT,n*n,length(preferred))';
    figure(2); subplot_tight(floor(sqrt(length(ranges))),ceil(length(ranges)/floor(sqrt(length(ranges)))),hiddenNo,[0.02 0.02]);
    q=quiver(reshape(real(hiddenLayer(hiddenNo,:)),n,n),reshape(imag(hiddenLayer(hiddenNo,:)),n,n),1.5);
    set(q,'color','b','linewidth',2);
    adjust_quiver_arrowhead_size(q,1.7);
    axis tight image;
end

% Outputlayer
outputLayer = W{2}(:,sorting(sorting2(ranges)))*hiddenLayer;
plotOutput = 1:5:size(W{2},1);
nOutput = 1;

for outputNo = plotOutput
    figure(3);
    subplot_tight(floor(sqrt(length(plotOutput))),ceil(length(plotOutput)/floor(sqrt(length(plotOutput)))),nOutput,[0.02 0.02]);
    q=quiver(reshape(real(outputLayer(outputNo,:)),n,n),reshape(imag(outputLayer(outputNo,:)),n,n),1.5);
    nOutput = nOutput+1;
    set(q,'color','b','linewidth',2);
    adjust_quiver_arrowhead_size(q,1.7);
    axis tight image;
end
