%% Parameter
global azi  viewDis; 
% close all
viewDis = 30;
% headings =   -8 * 0.5.^(0:5) ; %-30:1:-1;
headings =   89.99;
% headings = [headings 0 -headings(end:-1:1)];
%headings =88;

x = -30:5:30;  % cm
y = -30:5:30;  % cm
[X,Y] = meshgrid(x,y);

preferred = 0:22.5:355; % 0:45:315; % degree
response = zeros(numel(X) * length(preferred), length(headings));

h_opticalFlow = figure(4);
col=colormap(lines);

for h = 1:length(headings)
    
    
    %% Generate optical flow
    
    heading = headings(h);
        
    FOE = viewDis * tan(heading/180*pi);
    Z = 1/2*((X-FOE).^2 + Y.^2);
    [DX,DY] = gradient(Z,.2,.2);
% %{
    figure();
    hold on
    ds = 1;
    set(quiver(X(1:ds:end,1:ds:end),Y(1:ds:end,1:ds:end),DX(1:ds:end,1:ds:end),DY(1:ds:end,1:ds:end),1.1),'color',col(h,:),'linewidth',2)
    contour(X,Y,Z)
    colormap hsv
    axis square tight %off
%}  
  
    %% MT filter
    for pd = 1:length(preferred)
        xx = cos(preferred(pd)/180*pi);
        yy = sin(preferred(pd)/180*pi);
        input = DX*xx + DY*yy;    % Dot product
        resp = 1./ (1 + exp(-(input-700)/200));  % Slope is important!!;
        
        cutOff = round(length(x)/3);
        
        %{
        % Horizontal aperture
        resp(1:cutOff,:)=0;
        resp(end-cutOff+1:end,:)=0;
        %}
        
        %{
        % Vertical aperture
        resp(:,1:cutOff)=0;
        resp(:,end-cutOff+1:end)=0;
        %}
        
        %{
        % Center mask
        resp(cutOff+1:end-cutOff, cutOff+1:end-cutOff) = 0;
        
        %}
        
        %{
        figure(14); hold on
        plot(input(1:10:end),resp(1:10:end),'o')
        %}
        
        response(1+(pd-1)*numel(X):(pd)*numel(X),h) = (resp(:) - mean(resp(:))); %/ sqrt(sum(resp(:).^2));
    end

end

%% PCA analysis
% C = response * response';
% [V,D]=eig(C);
% [~, sorted] = sort(diag(D),'descend');
% V=V(:,sorted);

[V,score,latent] = princomp(response');
V(:,1)=-V(:,1);

%%
temp = reshape(V(:,1),length(X),length(X),1,length(preferred));
figure(5);  
n = length(x);

for i = 1:length(preferred)
    h = subplot_tight(floor(sqrt(length(preferred))),ceil(length(preferred)/floor(sqrt(length(preferred)))),i,[0.02 0.02]);
    imagesc(temp(:,:,1,i));
%     colormap(hot(256))
    colormap(jet)
    caxis([min(temp(:)) max(temp(:))]);
    axis(h,'square','off');
    hold on; 
    plot([n/2 n/2+n/4*cosd(preferred(i))]+0.5, [n/2 n/2+n/4*sind(preferred(i))]+0.5, 'k-','linewidth',4);
    plot(n/2+n/4*cosd(preferred(i))+0.5, n/2+n/4*sind(preferred(i))+0.5,'ok','markersize',10,'markerfacec','k');
end
% montage((temp-min(temp(:)))/range(temp(:))*2-1)
%

% Vector sum to get a "preferred optical flow" (Principle component)
prefVector = exp(preferred*pi/180*sqrt(-1));
vectorSum = prefVector * reshape(V(:,1),n*n,length(preferred))';
figure(1);
set(quiver(reshape(real(vectorSum),n,n),reshape(imag(vectorSum),n,n),1.5),'color','b','linewidth',2)
axis tight image;



figure(2);
pca1 = response' * V(:,1);
pca2 = response' * V(:,2);
pca3 = response' * V(:,3);
plot3(pca1,pca2,pca3,'*');
figure(3);
scatter(pca1(1:(length(headings)-1)/2),pca2(1:(length(headings)-1)/2),30*abs(headings(1:(length(headings)-1)/2)),'b','markerfacecol','b'); hold on;
scatter(pca1((length(headings)+1)/2+1:end),pca2((length(headings)+1)/2+1:end),30*abs(headings((length(headings)+1)/2+1:end)),'r','markerfacecol','r');
plot(pca1((length(headings)-1)/2+1),pca2((length(headings)-1)/2+1),'k*');
SetFigure(15);
xlabel('PC 1');
ylabel('PC 2');



%{
function dir = MSTazi2MTdir(x,y,azi)   % in degree
global  viewDis;
    
    for i = 1 : length(azi)
        if azi(i) >= 180 && azi(i) <= 360
            dir(i,1) = cart2pol(viewDis/tand(azi(i)-180)-x,-y)/pi*180;
        elseif azi (i) < 180 && azi(i) >= 0
            dir(i,1) = cart2pol(viewDis/tand(azi(i))-x,-y)/pi*180 + 180;
        end
    end
end
%}

