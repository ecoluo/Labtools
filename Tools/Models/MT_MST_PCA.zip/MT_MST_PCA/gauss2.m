function [fitresult, gof] = gauss2(X, Y, spike_rate_bin)
%CREATEFIT(X,Y,SPIKE_RATE_BIN)
%  Create a fit.
%
%  Data for 'gauss2' fit:
%      X Input : X
%      Y Input : Y
%      Z Output: spike_rate_bin
%  Output:
%      fitresult : a fit object representing the fit.
%      gof : structure with goodness-of fit info.
%
%  See also FIT, CFIT, SFIT.



%% Fit: 'gauss2'.
[xData, yData, zData] = prepareSurfaceData( X, Y, spike_rate_bin );

% Set up fittype and options.
ft = fittype( 'a1*exp(-(x-x0)^2/(2*sigmax^2)-(y-y0)^2/(2*sigmay^2))', 'independent', {'x', 'y'}, 'dependent', 'z' );
opts = fitoptions( ft );
opts.Display = 'Off';
opts.Lower = [-Inf -Inf -Inf -Inf -Inf];
opts.StartPoint = [0.754421506072111 0.879796987889695 0.46320342139819 0.274509665742597 0.474035884883833];
opts.Upper = [Inf Inf Inf Inf Inf];

% Fit model to data.
[fitresult, gof] = fit( [xData, yData], zData, ft, opts );

% Plot fit with data.

% figure( 'Name', 'gauss2' );
% h = plot( fitresult, [xData, yData], zData );
% legend( h, 'gauss2', 'spike_rate_bin vs. X, Y', 'Location', 'NorthEast' );
% % Label axes
% xlabel( 'X' );
% ylabel( 'Y' );
% zlabel( 'spike_rate_bin' );
% grid on


