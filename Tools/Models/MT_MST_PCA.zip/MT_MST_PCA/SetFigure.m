% set(gca,'xtickmode','auto');
% set(gca,'ytickmode','auto');
function setfigure(size)
% Shortcut summary goes here    
box off;
set(gcf,'color','w');
set(findall(gcf,'fontsize',10),'fontsize',size);
set(findall(gcf,'tickdir','i'),'tickdir','o');
set(findall(gcf,'type','axes','linewidth',0.5),'linewidth',2);
set(gca,'ticklength',[0.02 0])